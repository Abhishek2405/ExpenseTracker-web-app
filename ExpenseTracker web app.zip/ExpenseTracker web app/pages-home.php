<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Homepage</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>
<?php 
$income6 = $_POST["income5"];
$expenditure6 = $_POST["expenditure5"];
$name6 = $_POST["name5"];
$email6 = $_POST["email5"];
$username6 = $_POST["username5"];
?>
 
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">ExpenseTracker</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div>

    <nav class="header-nav ms-auto">
           <ul class="d-flex align-items-center">
        <li class="nav-item">
          <a class="nav-link collapsed" href="pages-login.php">
          <i class="bi bi-x-circle"></i>
          <span>Log-Out</span>
        </a>
        </li>    
        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.png" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $username6; ?></span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6><?php echo $name6; ?></h6>
              <span><?php echo $email6; ?></span>
            </li>
            </li>
      </ul>
    </nav>
  </header>
 
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link ">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li>
    </ul>
  </aside>
  
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div>

    <section class="section dashboard">
      <div class="row">

    
        <div class="col-lg-8">
          <div class="row">
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card sales-card">
                <div class="card-body">
                  <h5 class="card-title">Revenue</h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-cart"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo "$",$income6; ?></h6>

                    </div>
                  </div>
                </div>

              </div>
            </div>

   
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card revenue-card">
                <div class="card-body">
                  <h5 class="card-title">Expenses</h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-currency-dollar"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo "$",$expenditure6; ?></h6>

                    </div>
                  </div>
                </div>

              </div>
            </div>
<a style="color:DodgerBlue" href="pages-insert-expense.php">Click here to insert or remove Expense</a>
<label style="color:grey" for="msg">Note: After inserting or removing an Expense, you should Log-in again to save and view changes.</label>
            
            <div class="col-12">
              <div class="card top-selling">
                <div class="card-body pb-0">
                  <h5 class="card-title">Expenses</h5>
                  <table class="table table-borderless">
                    <thead>
                      <tr>
                        <th scope="col">Expense Name</th>
                        <th scope="col">Price($)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><a class="text-primary fw-bold"><?php
$conn = mysqli_connect("sql307.hstn.me","mseet_30346172","keerpal2405","mseet_30346172_459");
$sql = "SELECT ExpenseName FROM expenses WHERE Username = '$username6'";
$result = mysqli_query($conn,$sql);
while($row = $result->fetch_assoc()) {
    echo $row['ExpenseName'] , "<br>" , "<br>" , "<br>";
}
?></a></td>
                        <td><a class="text-primary fw-bold"></a><?php
$conn = mysqli_connect("sql307.hstn.me","mseet_30346172","keerpal2405","mseet_30346172_459");
$sql = "SELECT ExpensePrice FROM expenses WHERE Username = '$username6'";
$result = mysqli_query($conn,$sql);
while($row = $result->fetch_assoc()) {
    echo $row['ExpensePrice'] , "<br>" , "<br>" , "<br>" ;
}
?></td>
                      </tr>
<form action="pages-detailed-expense.php"  method="post">
<input type="hidden" name="detailname" value="<?php echo htmlspecialchars ($username6);?>" />		  
<button style="color:DodgerBlue; border:none; background-color:white;" type="submit">Click here to view a detailed version of your Expenses.</button>					  
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>

        
        <div class="col-lg-4">

          <div class="card">
            <div class="filter">
            </div>

            <div class="card-body pb-0">
              <h5 class="card-title">Income and Expense chart</h5>

              <div id="trafficChart" style="min-height: 400px;" class="echart"></div>

              <script>
                document.addEventListener("DOMContentLoaded", () => {
                  echarts.init(document.querySelector("#trafficChart")).setOption({
                    tooltip: {
                      trigger: 'item'
                    },
                    legend: {
                      top: '5%',
                      left: 'center'
                    },
                    series: [{
                      name: 'Access From',
                      type: 'pie',
                      radius: ['40%', '70%'],
                      avoidLabelOverlap: false,
                      label: {
                        show: false,
                        position: 'center'
                      },
                      emphasis: {
                        label: {
                          show: true,
                          fontSize: '18',
                          fontWeight: 'bold'
                        }
                      },
                      labelLine: {
                        show: false
                      },
                      data: [{
                          value: <?php echo $income6;?>,
                          name: 'Income'
                        },
                        {
                          value: <?php echo $expenditure6;?>,
                          name: 'Expense'
                        },
                      ]
                    }]
                  });
                });
              </script>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

 
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>

  <script src="assets/js/main.js"></script>
</body>
</html>