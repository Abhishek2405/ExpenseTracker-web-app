<?php 
session_start();

$username4 = $_POST["username"];
$password4 = $_POST["password4"];

$conn = mysqli_connect("sql307.hstn.me","mseet_30346172","keerpal2405","mseet_30346172_459");
$sql = "SELECT Name FROM userinfo WHERE Username = '$username4' and Password = '$password4'";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_array($result)) {
    $Name5 = $row['Name'];
}
$count = mysqli_num_rows($result);
if($count >= 1) {
		 $usernameokay = $username4;
      }elseif ($count == 0) {
		  header("location:pages-register(error).php");
      }else {
          echo "";
}

$conn2 = mysqli_connect("sql307.hstn.me","mseet_30346172","keerpal2405","mseet_30346172_459");
$sql2 = "SELECT Email FROM userinfo WHERE Username = '$username4' and Password = '$password4'";
$result2 = mysqli_query($conn2,$sql2);
while($row2 = mysqli_fetch_array($result2)) {
 	$Email5 = $row2['Email'];
}

$conn3 = mysqli_connect("sql307.hstn.me","mseet_30346172","keerpal2405","mseet_30346172_459");
$sql3 = "SELECT Income FROM userinfo WHERE Username = '$username4' and Password = '$password4'";
$result3 = mysqli_query($conn3,$sql3);
while($row3 = mysqli_fetch_array($result3)) {
	$Income5 = $row3['Income'];
}

$conn4 = mysqli_connect("sql307.hstn.me","mseet_30346172","keerpal2405","mseet_30346172_459");
$sql4 = "SELECT Expenditure FROM userinfo WHERE Username = '$username4' and Password = '$password4'";
$result4 = mysqli_query($conn4,$sql4);
while($row4 = mysqli_fetch_array($result4)) {
    $Expenditure5 = $row4['Expenditure'];
}
?>
<!DOCTYPE html>
<html>
<head>
<title>
</title>
</head>
<body>
<form action="pages-home.php"  method="post">
<input type="hidden" name="name5" value="<?php echo htmlspecialchars ($Name5);?>" />
<input type="hidden" name="email5" value="<?php echo htmlspecialchars($Email5);?>" />
<input type="hidden" name="username5" value="<?php echo htmlspecialchars($usernameokay);?>" />
<input type="hidden" name="income5" value="<?php echo htmlspecialchars($Income5);?>" />
<input type="hidden" name="expenditure5" value="<?php echo htmlspecialchars($Expenditure5);?>" />
<input id="button" type="submit" value="Submitted Successfully" style="border:none; background:none; color:DodgerBlue;">
<script>
window.onload = function(){
  document.getElementById('button').click();
}
</script>
</form>
</body>
</html>


